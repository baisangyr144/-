import 'package:flutter/material.dart';

/// Ряд наложенных друг на друга аватаров с счётчиком «+N».
class AvatarRow extends StatelessWidget {
  final List<String> initials;
  final int more;
  final double size;

  const AvatarRow({
    super.key,
    required this.initials,
    this.more = 0,
    this.size = 26,
  });

  static const _palette = [
    Color(0xFFFCA5A5),
    Color(0xFF93C5FD),
    Color(0xFFFCD34D),
    Color(0xFFA7F3D0),
  ];

  @override
  Widget build(BuildContext context) {
    final total = initials.length + (more > 0 ? 1 : 0);
    final step = size * 0.65;
    return SizedBox(
      width: step * (total - 1) + size,
      height: size,
      child: Stack(
        children: [
          for (var i = 0; i < total; i++)
            Positioned(
              left: i * step,
              child: Container(
                width: size,
                height: size,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 2),
                  color: i < initials.length
                      ? _palette[i % _palette.length]
                      : const Color(0xFF16A34A),
                ),
                child: Text(
                  i < initials.length ? initials[i] : '+$more',
                  style: TextStyle(
                    fontSize: size * 0.34,
                    fontWeight: FontWeight.bold,
                    color: i < initials.length ? Colors.black87 : Colors.white,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
