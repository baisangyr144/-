import 'package:flutter/material.dart';

import 'pages/easy/dashboard_page.dart';
import 'pages/easy/start_page.dart';
import 'pages/hard/course_details_page.dart';
import 'pages/hard/food_menu_page.dart';

void main() => runApp(const FigmaScreensApp());

class FigmaScreensApp extends StatelessWidget {
  const FigmaScreensApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Figma Screens',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF14B8A6),
        scaffoldBackgroundColor: const Color(0xFFF7F8FA),
      ),
      home: const RootPage(),
    );
  }
}

class _Screen {
  final String name;
  final String hint;
  final Color color;
  final IconData icon;
  final Widget page;

  const _Screen(this.name, this.hint, this.color, this.icon, this.page);
}

/// Корневой экран: две страницы, переключаются нижним меню.
class RootPage extends StatefulWidget {
  const RootPage({super.key});

  @override
  State<RootPage> createState() => _RootPageState();
}

class _RootPageState extends State<RootPage> {
  int _page = 0;

  static const _easy = [
    _Screen('Старт', 'Экран приветствия', Color(0xFF7C3AED), Icons.spa_outlined,
        StartPage()),
    _Screen('Дашборд', 'Задачи команды', Color(0xFF16A34A),
        Icons.dashboard_outlined, DashboardPage()),
  ];

  static const _hard = [
    _Screen('Меню', 'Популярные блюда', Color(0xFFF97316),
        Icons.lunch_dining_outlined, FoodMenuPage()),
    _Screen('Курс', 'Детали онлайн-курса', Color(0xFF0EA5E9),
        Icons.play_lesson_outlined, CourseDetailsPage()),
  ];

  @override
  Widget build(BuildContext context) {
    final screens = _page == 0 ? _easy : _hard;
    return Scaffold(
      appBar: AppBar(
        title: Text(_page == 0 ? 'Простые макеты' : 'Сложные макеты'),
      ),
      body: GridView.count(
        crossAxisCount: 2,
        padding: const EdgeInsets.all(16),
        mainAxisSpacing: 16,
        crossAxisSpacing: 16,
        children: [
          for (final s in screens)
            InkWell(
              borderRadius: BorderRadius.circular(24),
              onTap: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => s.page)),
              child: Ink(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: s.color,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(s.icon, color: Colors.white, size: 36),
                    const Spacer(),
                    Text(s.name,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold)),
                    Text(s.hint,
                        style: const TextStyle(color: Colors.white70)),
                  ],
                ),
              ),
            ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _page,
        onDestinationSelected: (i) => setState(() => _page = i),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.filter_1_outlined), label: 'Страница 1'),
          NavigationDestination(
              icon: Icon(Icons.filter_2_outlined), label: 'Страница 2'),
        ],
      ),
    );
  }
}
