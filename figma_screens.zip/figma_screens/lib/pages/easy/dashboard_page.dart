import 'package:flutter/material.dart';

import '../../widgets/avatar_row.dart';

/// Простой макет 2 — дашборд задач команды.
class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  static const _green = Color(0xFF16A34A);

  int _tab = 0;
  final Map<String, bool> _today = {
    'Сверстать экран оплаты': true,
    'Обновить главную страницу': false,
    'Созвон с заказчиком': false,
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            // Зелёная шапка
            SliverToBoxAdapter(
              child: Container(
                margin: const EdgeInsets.all(16),
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: _green,
                  borderRadius: BorderRadius.circular(28),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const CircleAvatar(
                          backgroundColor: Colors.white,
                          child: Text('МК',
                              style: TextStyle(
                                  color: _green, fontWeight: FontWeight.bold)),
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Привет 👋',
                                  style: TextStyle(color: Colors.white70)),
                              Text('Марк Ковалёв',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold)),
                            ],
                          ),
                        ),
                        IconButton.filledTonal(
                            onPressed: () {},
                            icon: const Icon(Icons.notifications_outlined)),
                      ],
                    ),
                    const SizedBox(height: 20),
                    const Text('На этой неделе выполнено',
                        style: TextStyle(color: Colors.white70)),
                    const SizedBox(height: 8),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: const LinearProgressIndicator(
                        value: 0.62,
                        minHeight: 10,
                        backgroundColor: Colors.white24,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 6),
                    const Text('10 из 16 задач',
                        style: TextStyle(
                            color: Colors.white, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ),
            _title('Задачи недели', 'смотреть все'),
            SliverToBoxAdapter(
              child: SizedBox(
                height: 150,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: const [
                    _ProjectCard('Лендинг для студии', 'Дизайн',
                        Color(0xFFFEF3C7), ['АН', 'ИП'], 4),
                    _ProjectCard('Сайт кофейни', 'Разработка',
                        Color(0xFFDBEAFE), ['ОС', 'ЕВ', 'ТК'], 2),
                    _ProjectCard('Логотип бренда', 'Брендинг',
                        Color(0xFFFCE7F3), ['ДР'], 1),
                  ],
                ),
              ),
            ),
            _title('Сегодня', '${_today.values.where((v) => v).length}/${_today.length}'),
            SliverList.list(
              children: [
                for (final e in _today.entries)
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
                    child: Material(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(18),
                      child: CheckboxListTile(
                        value: e.value,
                        onChanged: (v) =>
                            setState(() => _today[e.key] = v ?? false),
                        activeColor: _green,
                        controlAffinity: ListTileControlAffinity.leading,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18)),
                        title: Text(
                          e.key,
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: e.value ? Colors.grey : Colors.black87,
                            decoration:
                                e.value ? TextDecoration.lineThrough : null,
                          ),
                        ),
                        subtitle: const Text('Сегодня, 18:00'),
                        secondary: const AvatarRow(initials: ['АН'], more: 2),
                      ),
                    ),
                  ),
                const SizedBox(height: 16),
              ],
            ),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        indicatorColor: const Color(0xFFDCFCE7),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.space_dashboard_outlined), label: 'Обзор'),
          NavigationDestination(icon: Icon(Icons.work_outline), label: 'Проекты'),
          NavigationDestination(icon: Icon(Icons.event_outlined), label: 'План'),
          NavigationDestination(icon: Icon(Icons.forum_outlined), label: 'Чаты'),
        ],
      ),
    );
  }

  Widget _title(String text, String action) => SliverPadding(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 10),
        sliver: SliverToBoxAdapter(
          child: Row(
            children: [
              Text(text,
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold)),
              const Spacer(),
              Text(action, style: const TextStyle(color: _green)),
            ],
          ),
        ),
      );
}

class _ProjectCard extends StatelessWidget {
  final String title;
  final String tag;
  final Color color;
  final List<String> people;
  final int more;

  const _ProjectCard(this.title, this.tag, this.color, this.people, this.more);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 170,
      margin: const EdgeInsets.only(right: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(tag.toUpperCase(),
              style: const TextStyle(
                  fontSize: 11,
                  letterSpacing: 1,
                  fontWeight: FontWeight.w600,
                  color: Colors.black54)),
          const SizedBox(height: 6),
          Text(title,
              style:
                  const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const Spacer(),
          Row(
            children: [
              AvatarRow(initials: people, more: more),
              const Spacer(),
              const Icon(Icons.arrow_forward, size: 18),
            ],
          ),
        ],
      ),
    );
  }
}
