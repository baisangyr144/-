import 'package:flutter/material.dart';

/// Простой макет 1 — экран приветствия приложения для медитаций.
class StartPage extends StatelessWidget {
  const StartPage({super.key});

  static const _purple = Color(0xFF7C3AED);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF8B5CF6), Color(0xFF5B21B6)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          bottom: false,
          child: Column(
            children: [
              Align(
                alignment: Alignment.topLeft,
                child: BackButton(color: Colors.white),
              ),
              // Иллюстрация: концентрические круги и фигура в позе лотоса
              Expanded(
                child: Center(
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      for (final r in [240.0, 180.0, 120.0])
                        Container(
                          width: r,
                          height: r,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white.withOpacity(0.08),
                          ),
                        ),
                      const Icon(Icons.self_improvement,
                          size: 130, color: Colors.white),
                      const Positioned(
                        left: 0,
                        bottom: 10,
                        child: Icon(Icons.local_florist,
                            size: 48, color: Color(0xFFDDD6FE)),
                      ),
                      const Positioned(
                        right: 0,
                        top: 10,
                        child: Icon(Icons.nightlight_round,
                            size: 40, color: Color(0xFFFDE68A)),
                      ),
                    ],
                  ),
                ),
              ),
              // Нижняя панель с кнопками
              Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(28, 32, 28, 36),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius:
                      BorderRadius.vertical(top: Radius.circular(36)),
                ),
                child: Column(
                  children: [
                    const Text('calmo',
                        style: TextStyle(
                            fontSize: 34,
                            fontWeight: FontWeight.w900,
                            color: _purple)),
                    const SizedBox(height: 4),
                    const Text('Найди минуту тишины каждый день',
                        style: TextStyle(color: Colors.black54)),
                    const SizedBox(height: 28),
                    _button(context, 'Войти через Apple', Icons.apple,
                        Colors.black, Colors.white),
                    const SizedBox(height: 12),
                    _button(context, 'Почта или телефон', Icons.mail_outline,
                        const Color(0xFFEDE9FE), _purple),
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      onPressed: () => _toast(context, 'Google'),
                      icon: const Icon(Icons.g_mobiledata, size: 28),
                      label: const Text('Через Google'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.black87,
                        minimumSize: const Size.fromHeight(50),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14)),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _toast(BuildContext context, String way) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text('Вход: $way')));

  Widget _button(BuildContext context, String text, IconData icon, Color bg,
      Color fg) {
    return FilledButton.icon(
      onPressed: () => _toast(context, text),
      icon: Icon(icon),
      label: Text(text),
      style: FilledButton.styleFrom(
        backgroundColor: bg,
        foregroundColor: fg,
        minimumSize: const Size.fromHeight(50),
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }
}
