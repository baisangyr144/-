import 'package:flutter/material.dart';

/// Сложный макет 1 — популярные блюда.
class FoodMenuPage extends StatefulWidget {
  const FoodMenuPage({super.key});

  @override
  State<FoodMenuPage> createState() => _FoodMenuPageState();
}

class _Food {
  final String title;
  final String cafe;
  final double price;
  final String emoji;
  final String type;

  const _Food(this.title, this.cafe, this.price, this.emoji, this.type);
}

class _FoodMenuPageState extends State<FoodMenuPage> {
  static const _orange = Color(0xFFF97316);
  static const _cream = Color(0xFFFFF7ED);

  static const _types = ['Всё', 'Горячее', 'Салаты', 'Десерты'];
  static const _foods = [
    _Food('Паста карбонара', 'Trattoria 12', 8.5, '🍝', 'Горячее'),
    _Food('Греческий салат', 'Green Bowl', 6.9, '🥗', 'Салаты'),
    _Food('Пломбир с ягодами', 'Ice Point', 4.5, '🍨', 'Десерты'),
    _Food('Рамен с курицей', 'Noodle Bar', 10.2, '🍜', 'Горячее'),
    _Food('Боул с лососем', 'Poke Lab', 11.0, '🥙', 'Салаты'),
    _Food('Чизкейк', 'Sweet Home', 5.3, '🍰', 'Десерты'),
  ];

  int _type = 0;
  String _search = '';
  final Map<String, int> _basket = {};

  int get _count => _basket.values.fold(0, (a, b) => a + b);

  @override
  Widget build(BuildContext context) {
    final list = _foods.where((f) {
      final okType = _type == 0 || f.type == _types[_type];
      return okType && f.title.toLowerCase().contains(_search.toLowerCase());
    }).toList();

    return Scaffold(
      backgroundColor: _cream,
      appBar: AppBar(
        backgroundColor: _cream,
        leading: const BackButton(),
        title: const Text('Популярное',
            style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Badge.count(
              count: _count,
              isLabelVisible: _count > 0,
              backgroundColor: _orange,
              child: const Icon(Icons.shopping_bag_outlined, size: 28),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          // Поиск
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
            child: SearchBar(
              hintText: 'Найти блюдо',
              leading: const Icon(Icons.search),
              trailing: const [Icon(Icons.tune, color: _orange)],
              elevation: const MaterialStatePropertyAll(0),
              backgroundColor: const MaterialStatePropertyAll(Colors.white),
              onChanged: (v) => setState(() => _search = v),
            ),
          ),
          // Категории
          SizedBox(
            height: 42,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: _types.length,
              itemBuilder: (_, i) => Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: GestureDetector(
                  onTap: () => setState(() => _type = i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    padding: const EdgeInsets.symmetric(horizontal: 18),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: i == _type ? _orange : Colors.white,
                      borderRadius: BorderRadius.circular(21),
                    ),
                    child: Text(_types[i],
                        style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: i == _type ? Colors.white : Colors.black87)),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          // Список блюд
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: list.length,
              itemBuilder: (_, i) => _FoodTile(
                food: list[i],
                count: _basket[list[i].title] ?? 0,
                onAdd: () => setState(() =>
                    _basket[list[i].title] = (_basket[list[i].title] ?? 0) + 1),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _FoodTile extends StatelessWidget {
  final _Food food;
  final int count;
  final VoidCallback onAdd;

  const _FoodTile(
      {required this.food, required this.count, required this.onAdd});

  @override
  Widget build(BuildContext context) {
    const orange = Color(0xFFF97316);
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: orange.withOpacity(0.10),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          // Картинка блюда «выходит» за левый край карточки
          Container(
            width: 86,
            height: 86,
            margin: const EdgeInsets.all(8),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [orange.withOpacity(0.25), const Color(0xFFFFF7ED)],
              ),
            ),
            child: Text(food.emoji, style: const TextStyle(fontSize: 42)),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(food.title,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Row(
                  children: [
                    const Icon(Icons.storefront, size: 14, color: Colors.grey),
                    const SizedBox(width: 4),
                    Text(food.cafe,
                        style:
                            const TextStyle(color: Colors.grey, fontSize: 13)),
                  ],
                ),
                const SizedBox(height: 8),
                Text('\$${food.price.toStringAsFixed(1)}',
                    style: const TextStyle(
                        color: orange,
                        fontSize: 18,
                        fontWeight: FontWeight.w800)),
              ],
            ),
          ),
          // Кнопка добавления со счётчиком
          Padding(
            padding: const EdgeInsets.only(right: 14),
            child: Column(
              children: [
                IconButton.filled(
                  onPressed: onAdd,
                  style: IconButton.styleFrom(backgroundColor: orange),
                  icon: const Icon(Icons.add),
                ),
                if (count > 0)
                  Text('× $count',
                      style: const TextStyle(fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
