import 'package:flutter/material.dart';

/// Сложный макет 2 — детали онлайн-курса.
class CourseDetailsPage extends StatefulWidget {
  const CourseDetailsPage({super.key});

  @override
  State<CourseDetailsPage> createState() => _CourseDetailsPageState();
}

class _CourseDetailsPageState extends State<CourseDetailsPage> {
  static const _sky = Color(0xFF0EA5E9);
  static const _navy = Color(0xFF0F172A);

  bool _saved = false;

  static const _modules = {
    'Модуль 1. Знакомство с 3D': ['Интерфейс программы', 'Первая сцена'],
    'Модуль 2. Моделирование': ['Примитивы', 'Модификаторы', 'Скульптинг'],
    'Модуль 3. Свет и рендер': ['Материалы', 'Освещение', 'Финальный рендер'],
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: CustomScrollView(
        slivers: [
          // Растягивающаяся обложка
          SliverAppBar(
            expandedHeight: 260,
            pinned: true,
            backgroundColor: _navy,
            foregroundColor: Colors.white,
            actions: [
              IconButton(
                onPressed: () => setState(() => _saved = !_saved),
                icon: Icon(_saved ? Icons.bookmark : Icons.bookmark_border),
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              title: const Text('3D для начинающих',
                  style: TextStyle(fontSize: 16)),
              background: Stack(
                fit: StackFit.expand,
                children: [
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: SweepGradient(
                        colors: [
                          Color(0xFF0EA5E9),
                          Color(0xFF6366F1),
                          Color(0xFFEC4899),
                          Color(0xFF0EA5E9),
                        ],
                      ),
                    ),
                  ),
                  // Полупрозрачные «стеклянные» фигуры
                  for (final (l, t, s) in const [
                    (30.0, 60.0, 90.0),
                    (220.0, 30.0, 130.0),
                    (140.0, 140.0, 70.0),
                  ])
                    Positioned(
                      left: l,
                      top: t,
                      child: Transform.rotate(
                        angle: 0.6,
                        child: Container(
                          width: s,
                          height: s,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.18),
                            borderRadius: BorderRadius.circular(s / 4),
                            border: Border.all(color: Colors.white38),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(20),
            sliver: SliverList.list(
              children: [
                // Показатели курса
                Row(
                  children: [
                    _stat(Icons.star_rounded, '4.9', 'рейтинг'),
                    _stat(Icons.group_outlined, '4 569', 'учеников'),
                    _stat(Icons.schedule, '20 ч', 'видео'),
                  ],
                ),
                const SizedBox(height: 20),
                Wrap(
                  spacing: 8,
                  children: const [
                    Chip(label: Text('Хит продаж')),
                    Chip(label: Text('Для новичков')),
                    Chip(label: Text('Сертификат')),
                  ],
                ),
                const SizedBox(height: 16),
                const Text('О курсе',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text(
                  'Курс поможет освоить объёмное моделирование с нуля: от '
                  'первой сцены до готового рендера продукта. В программе '
                  '24 видеоурока и практические задания.',
                  style: TextStyle(height: 1.5, color: Colors.black87),
                ),
                const SizedBox(height: 20),
                const Text('Программа',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                // Раскрывающиеся модули
                for (final m in _modules.entries)
                  Card(
                    elevation: 0,
                    color: const Color(0xFFF0F9FF),
                    margin: const EdgeInsets.only(bottom: 10),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                    child: ExpansionTile(
                      shape: const Border(),
                      leading: const CircleAvatar(
                        backgroundColor: _sky,
                        foregroundColor: Colors.white,
                        child: Icon(Icons.play_arrow),
                      ),
                      title: Text(m.key,
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text('${m.value.length} урока'),
                      children: [
                        for (final lesson in m.value)
                          ListTile(
                            dense: true,
                            leading: const Icon(Icons.ondemand_video,
                                color: _sky),
                            title: Text(lesson),
                            trailing: const Text('15 мин'),
                          ),
                      ],
                    ),
                  ),
                const SizedBox(height: 80),
              ],
            ),
          ),
        ],
      ),
      // Нижняя панель с ценой
      bottomSheet: Container(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
        decoration: const BoxDecoration(
          color: _navy,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Row(
          children: [
            const Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Стоимость', style: TextStyle(color: Colors.white60)),
                Text('\$24.99',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(width: 20),
            Expanded(
              child: FilledButton(
                onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Курс добавлен'))),
                style: FilledButton.styleFrom(
                  backgroundColor: _sky,
                  minimumSize: const Size.fromHeight(52),
                ),
                child: const Text('Начать обучение',
                    style: TextStyle(fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _stat(IconData icon, String value, String label) => Expanded(
        child: Column(
          children: [
            Icon(icon, color: _sky),
            const SizedBox(height: 4),
            Text(value,
                style:
                    const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Text(label,
                style: const TextStyle(fontSize: 12, color: Colors.grey)),
          ],
        ),
      );
}
