# Figma Screens

Практическая работа: вёрстка макетов из Figma на Flutter.

```
lib/
├── main.dart                      — корневой экран, 2 страницы (нижнее меню)
├── widgets/avatar_row.dart        — общий виджет «ряд аватаров»
└── pages/
    ├── easy/                      — страница 1: простые макеты
    │   ├── start_page.dart        — экран приветствия
    │   └── dashboard_page.dart    — дашборд задач
    └── hard/                      — страница 2: сложные макеты
        ├── food_menu_page.dart    — популярные блюда
        └── course_details_page.dart — детали курса
```

Запуск:

```bash
flutter create .
flutter pub get
flutter run
```
